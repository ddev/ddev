-- MySQL dump 10.17  Distrib 10.3.25-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.3.25-MariaDB-1:10.3.25+maria~focal-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users_field_data`
--

DROP TABLE IF EXISTS `users_field_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_field_data` (
  `uid` int(10) unsigned NOT NULL,
  `langcode` varchar(12) CHARACTER SET ascii NOT NULL,
  `preferred_langcode` varchar(12) CHARACTER SET ascii DEFAULT NULL,
  `preferred_admin_langcode` varchar(12) CHARACTER SET ascii DEFAULT NULL,
  `name` varchar(60) NOT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `mail` varchar(254) DEFAULT NULL,
  `timezone` varchar(32) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `created` int(11) NOT NULL,
  `changed` int(11) DEFAULT NULL,
  `access` int(11) NOT NULL,
  `login` int(11) DEFAULT NULL,
  `init` varchar(254) DEFAULT NULL,
  `default_langcode` tinyint(4) NOT NULL,
  PRIMARY KEY (`uid`,`langcode`),
  UNIQUE KEY `user__name` (`name`,`langcode`),
  KEY `user__id__default_langcode__langcode` (`uid`,`default_langcode`,`langcode`),
  KEY `user_field__mail` (`mail`(191)),
  KEY `user_field__created` (`created`),
  KEY `user_field__access` (`access`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='The data table for user entities.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_field_data`
--

LOCK TABLES `users_field_data` WRITE;
/*!40000 ALTER TABLE `users_field_data` DISABLE KEYS */;
INSERT INTO `users_field_data` VALUES (0,'en','en',NULL,'',NULL,NULL,'',0,1607648984,1607648984,0,0,NULL,1),(1,'en','en',NULL,'rfay','$S$EKRV6EfPssPjeTd6LJa2F3d6NT5aVPJ','randy@example.com','America/Denver',1,1607648984,1607649429,1607649513,1607649445,'randy@randyfay.com',1),(2,'en','en',NULL,'Margaret Hopper','$S$EIW59TcQLurkJSuVRREcy/YJVmrK.VdWcOswWlQzy1ud7O0iJuAR','margaret.hopper@example.com','America/Denver',1,1607649088,1607649429,0,0,NULL,1),(3,'en','en',NULL,'Grace Hamilton','$S$E2ScxLZmFPH2zthUj35bAO5.t/hB1hqQQMLi5zPBLgBVRNY67Ktp','grace.hamilton@example.com','America/Denver',1,1607649088,1607649429,0,0,NULL,1),(4,'en','en',NULL,'Umami','$S$EHpkqR/sUpnTiuHOB/exfMQL85bqp9eyggnEP5jvFXHOZdWJYOvH','umami@example.com','America/Denver',1,1607649088,1607649429,0,0,NULL,1),(5,'en','en',NULL,'Holly Foat','$S$EM3d3bAEO9tMF1AHwQNYjf0.cqpfYYkFNFE8OsKdrlpTC0ezjOWp','holly.foat@example.com','America/Denver',1,1607649088,1607649429,0,0,NULL,1),(6,'en','en',NULL,'Megan Collins Quinlan','$S$EKspRl4w7/b.yM6luRAJunwb5jsIlpe9ZsccR.wjmwvK9cNXj795','megan.collins.quinlan@example.com','America/Denver',1,1607649088,1607649429,0,0,NULL,1),(7,'en','en',NULL,'Samuel Adamson','$S$ELt8HfQeIE8YJxfljx8FQYNYxT976q9/1dyhrYvhmOBK8pTEGhv8','samuel.adamson@example.com','America/Denver',1,1607649088,1607649429,0,0,NULL,1);
/*!40000 ALTER TABLE `users_field_data` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-02-02 14:47:57

